function callAjax(url,inParam) {

} 
 
 
 